<?php get_header(); ?>
<h1>Welcome to My E-commerce Theme</h1>
<?php get_footer(); ?>