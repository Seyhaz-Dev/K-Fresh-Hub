</main>
<footer>
<p>© <?php echo date('Y'); ?> My Shop</p>
</footer>
<?php wp_footer(); ?>
</body></html>